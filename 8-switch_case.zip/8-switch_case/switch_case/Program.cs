﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace switch_case
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("set console color RED = 1 ");
            Console.WriteLine("set console color GREEN = 2 ");
            Console.WriteLine("set console color BLUE = 3 ");
            int n = Convert.ToInt32(Console.ReadLine());

            switch (n)
            {
                case 1: Console.BackgroundColor = ConsoleColor.Red;
                    Console.Clear();
                    break;
                case 2: Console.BackgroundColor = ConsoleColor.Green;
                    Console.Clear();
                    break;
                case 3: Console.BackgroundColor = ConsoleColor.Blue;
                    Console.Clear();
                    break;
                default: Console.Write("Please Select 1 2 3");
                    break;
            }
            Console.Read();
        }
    }
}
